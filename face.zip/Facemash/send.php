<?php
$t=time();
echo($t . "<br>");
?>
